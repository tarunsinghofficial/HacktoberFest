public class ILoveYouAsAFriendException extends Exception
{
    public ILoveYouAsAFriendException()
    {
        super("Girls will love you as a friend if you're younger than them.");
    }
}