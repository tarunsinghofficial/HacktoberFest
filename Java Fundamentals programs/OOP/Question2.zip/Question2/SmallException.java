public class SmallException extends Exception
{
    public SmallException()
    {
        super("1st number cannot be smaller than second number");
    }
}