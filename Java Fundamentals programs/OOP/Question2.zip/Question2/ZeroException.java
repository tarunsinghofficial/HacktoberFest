public class ZeroException extends Exception
{
    public ZeroException()
    {
        super("second number cannot be equal to Zero");
    }
}